# README

This is the smallest-possible example program using libopencm3.

It's intended for the [Diolan LPC-4350-DB1](http://www.diolan.com/lpc4350-features.html).

It should blink D2 on the board.

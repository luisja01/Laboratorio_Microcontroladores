# README

This program exercises the I2C peripheral on Jellybean's LPC43xx.  You can
scope SCL on P6 pin 3 and SDA on P6 pin 5.  If Lemondrop is connected, LED1
will illuminate if I2C communication to the Si5351C on Lemondrop is successful.

Required Lemondrop -> Jellybean connections:

    SCL: Lemondrop P7 pin 3 -> Jellybean P6 pin 3
    SDA: Lemondrop P7 pin 5 -> Jellybean P6 pin 5
    VCC: Lemondrop P4 pin 2, 4, or 6 -> Jellybean P17 pin 2, 4, or 6
    1V8: Lemondrop P11 pin 2, 4, or 6 -> Jellybean P16 pin 2, 4, or 6
    GND: Lemondrop P5 -> Jellybean P13

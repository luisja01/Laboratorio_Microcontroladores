# README

This is the smallest-possible example program using libopencm3.

It's intended for the NXP LPC1768-based
[NGX Blueboard-LPC1768-H eval board](http://shop.ngxtechnologies.com/product_info.php?cPath=21&products_id=65).
It should blink a LED on the board.

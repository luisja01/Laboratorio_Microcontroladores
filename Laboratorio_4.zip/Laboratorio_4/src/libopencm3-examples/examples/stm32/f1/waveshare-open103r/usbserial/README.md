# README

This example uses the USB port as a serial port and implements a
loopback interface that immediately echos back whatever it receives. After flashing the evaluation board with the usbserial program and connecting it to a host computer with a USB cable, you can run the echo.py command as follows:

$ sudo ./echo.py hello world
hello world
$

# README

This is the smallest-possible example program using libopencm3.

It's intended for the WaveShare Open103R eval board. It should blink
the red LED labeled LED1 on the board.


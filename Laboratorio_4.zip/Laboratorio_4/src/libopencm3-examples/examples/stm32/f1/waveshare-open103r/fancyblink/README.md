# README

This program will interleave the blinking of two sets of LEDs. LED1
and LED3 will blink at the same time and LED2 and LED4 will blink at
the same time. When LED1 and LED3 are on, LED2 and LED4 will be off,
and vice versa.


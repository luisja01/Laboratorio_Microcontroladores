# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32-based
[Leaf Labs Maple board](http://leaflabs.com).
It should blink the LED on the board.

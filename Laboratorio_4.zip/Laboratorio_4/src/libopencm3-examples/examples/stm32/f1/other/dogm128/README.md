# README

This example program writes some text on an DOGM128 LCD display connected
to SPI2.


# README

This example program sends some characters on USART1.
Afterwards it read out the internal temperature sensor of the STM32 and
sends the value read out from the ADC to the USART1.

The terminal settings for the receiving device/PC are 115200 8n1.


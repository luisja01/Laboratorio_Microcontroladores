# README

This experimental program sends some characters on the TRACESWO pin using 
the Instrumentation Trace Macrocell (ITM) and Trace Port Interface Unit (TPIU).

The SWJ-DP port must be in SWD mode and not JTAG mode for the output
to be visible.


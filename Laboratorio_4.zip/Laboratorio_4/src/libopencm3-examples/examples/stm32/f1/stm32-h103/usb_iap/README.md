# README

This example implements a USB bootloader for the Paparazzi project.

TODO: Move to examples/lisa-m?


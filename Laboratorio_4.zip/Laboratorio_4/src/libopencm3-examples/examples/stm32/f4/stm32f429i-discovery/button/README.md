# README

This example blinks the GREEN LED on the ST STM32F429IDISCOVERY eval board.

When you press the 'USER' button, the blinking is slower.

## Board connections

*none required*

# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32F4DISCOVERY eval board. It should blink
the LEDs on the board.

## Board connections

*none required*

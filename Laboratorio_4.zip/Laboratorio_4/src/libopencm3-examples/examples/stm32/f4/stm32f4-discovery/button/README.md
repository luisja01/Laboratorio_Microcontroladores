# README

This example blinks the GREEN LED on the ST STM32F4DISCOVERY eval board.

When you press the 'USER' button, the blinking is slower.

## Board connections

*none required*

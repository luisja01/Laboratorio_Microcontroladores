# README

This example implements a USB Mass Storage Class (MSC) device
to demonstrate the use of the USB device stack.


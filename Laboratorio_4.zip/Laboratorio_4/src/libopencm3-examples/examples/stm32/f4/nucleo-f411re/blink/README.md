# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST Nucleo-F411RE eval board. It should blink
the GREEN LED on the board.

## Board connections

*none required*

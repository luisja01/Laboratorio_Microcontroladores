# README

This is the smallest-possible example program using libopencm3.

